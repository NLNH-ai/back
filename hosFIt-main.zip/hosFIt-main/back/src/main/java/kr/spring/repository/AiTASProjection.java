package kr.spring.repository;

public interface AiTASProjection  {
	
	 	Long getLevel1();
	    Long getLevel2();
	    Long getLevel3();

}
