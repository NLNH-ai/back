package kr.spring.entity;

public interface MemberInterface {
    String getName();
    String getPosition();
    String getDepartment();
    String getMajor();
}
